var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/fetchLeaderboard.js
var fetchLeaderboard_exports = {};
__export(fetchLeaderboard_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(fetchLeaderboard_exports);
async function handler(event) {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: cors(event), body: "" };
  }
  if (event.httpMethod !== "GET") {
    return json(405, { error: "Method Not Allowed" }, cors(event));
  }
  try {
    const demo = [
      { uid: "u1", name: "Player 1", xp: 1200, streak: 5, rank: 1, tier: "free" }
    ];
    return json(200, demo, cors(event));
  } catch (err) {
    console.error("fetchLeaderboard error", err);
    return json(500, { error: "Internal error" }, cors(event));
  }
}
var json = (s, d, h = {}) => ({
  statusCode: s,
  headers: { "content-type": "application/json; charset=utf-8", ...h },
  body: JSON.stringify(d)
});
var cors = (e) => ({
  "Access-Control-Allow-Origin": e.headers?.origin || "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization"
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
