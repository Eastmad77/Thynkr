var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/echo.js
var echo_exports = {};
__export(echo_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(echo_exports);
var json = (s, d, h = {}) => ({ statusCode: s, headers: { "content-type": "application/json", ...h }, body: JSON.stringify(d) });
var allowOrigin = (e) => e.headers.origin || "*";
var cors = (e) => ({ "Access-Control-Allow-Origin": allowOrigin(e), "Access-Control-Allow-Headers": "authorization,content-type", "Access-Control-Allow-Methods": "GET,POST,OPTIONS" });
async function handler(event) {
  if (event.httpMethod === "OPTIONS")
    return { statusCode: 204, headers: cors(event) };
  const body = event.body ? JSON.parse(event.body) : null;
  return json(200, { ok: true, method: event.httpMethod, body }, cors(event));
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
