var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/create-portal-session.js
var create_portal_session_exports = {};
__export(create_portal_session_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(create_portal_session_exports);
var import_stripe = __toESM(require("stripe"), 1);

// netlify/functions/_shared/firebase-admin.mjs
var import_firebase_admin = __toESM(require("firebase-admin"), 1);
var _app = null;
var _db = null;
var _using = false;
function getAdmin() {
  if (_app)
    return { admin: import_firebase_admin.default, db: _db, using: _using };
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT || "";
  if (!raw) {
    console.warn("[firebase-admin] FIREBASE_SERVICE_ACCOUNT not set; Firebase disabled.");
    return { admin: import_firebase_admin.default, db: null, using: false };
  }
  let creds;
  try {
    const json = raw.trim().startsWith("{") ? raw : Buffer.from(raw, "base64").toString("utf8");
    creds = JSON.parse(json);
  } catch (e) {
    console.error("[firebase-admin] Could not parse FIREBASE_SERVICE_ACCOUNT:", e?.message || e);
    return { admin: import_firebase_admin.default, db: null, using: false };
  }
  _app = import_firebase_admin.default.apps?.length ? import_firebase_admin.default.app() : import_firebase_admin.default.initializeApp({
    credential: import_firebase_admin.default.credential.cert(creds),
    projectId: process.env.FIREBASE_PROJECT_ID || creds.project_id
  });
  _db = import_firebase_admin.default.firestore();
  _using = true;
  return { admin: import_firebase_admin.default, db: _db, using: _using };
}

// netlify/functions/create-portal-session.js
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json; charset=utf-8"
};
async function handler(event) {
  if (event.httpMethod === "OPTIONS")
    return { statusCode: 200, headers: CORS, body: "" };
  if (event.httpMethod !== "POST")
    return { statusCode: 405, headers: CORS, body: JSON.stringify({ error: "Method not allowed" }) };
  try {
    const { STRIPE_SECRET_KEY } = process.env;
    if (!STRIPE_SECRET_KEY)
      throw new Error("STRIPE_SECRET_KEY missing");
    const stripe = new import_stripe.default(STRIPE_SECRET_KEY, { apiVersion: "2024-06-20" });
    const { uid } = JSON.parse(event.body || "{}");
    if (!uid)
      return { statusCode: 400, headers: CORS, body: JSON.stringify({ error: "Missing uid" }) };
    const { db } = getAdmin();
    if (!db)
      return { statusCode: 501, headers: CORS, body: JSON.stringify({ error: "Admin not configured" }) };
    const snap = await db.collection("users").doc(uid).get();
    const data = snap.exists ? snap.data() || {} : {};
    const customerId = data?.stripeCustomerId;
    if (!customerId)
      return { statusCode: 400, headers: CORS, body: JSON.stringify({ error: "No Stripe customer on file" }) };
    const siteUrl = process.env.SITE_URL || (event.headers.origin ? event.headers.origin : `https://${event.headers.host}`);
    const session = await stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: siteUrl
    });
    return { statusCode: 200, headers: CORS, body: JSON.stringify({ url: session.url }) };
  } catch (err) {
    console.error("[create-portal-session] error:", err);
    return { statusCode: 500, headers: CORS, body: JSON.stringify({ error: "Portal error" }) };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
