var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/_firebase-admin.js
var firebase_admin_exports = {};
__export(firebase_admin_exports, {
  getAdmin: () => getAdmin
});
module.exports = __toCommonJS(firebase_admin_exports);
var import_firebase_admin = __toESM(require("firebase-admin"), 1);
var app;
function getAdmin() {
  if (!app) {
    const b64 = process.env.FIREBASE_SERVICE_ACCOUNT;
    if (!b64)
      throw new Error("FIREBASE_SERVICE_ACCOUNT missing");
    const json = Buffer.from(b64, "base64").toString("utf8");
    const creds = JSON.parse(json);
    app = import_firebase_admin.default.initializeApp({
      credential: import_firebase_admin.default.credential.cert(creds)
    });
  }
  const db = import_firebase_admin.default.firestore();
  return { admin: import_firebase_admin.default, db };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getAdmin
});
