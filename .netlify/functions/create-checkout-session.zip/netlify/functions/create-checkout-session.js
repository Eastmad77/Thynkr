var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/create-checkout-session.js
var create_checkout_session_exports = {};
__export(create_checkout_session_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(create_checkout_session_exports);
var import_stripe = __toESM(require("stripe"), 1);
var stripe = new import_stripe.default(process.env.STRIPE_SECRET_KEY, { apiVersion: "2023-10-16" });
var json = (status, data, headers = {}) => ({
  statusCode: status,
  headers: { "content-type": "application/json", ...headers },
  body: JSON.stringify(data)
});
var allowOrigin = (evt) => evt.headers.origin || "*";
var cors = (evt, extra = {}) => ({
  "Access-Control-Allow-Origin": allowOrigin(evt),
  "Access-Control-Allow-Headers": "authorization,content-type",
  "Access-Control-Allow-Methods": "POST,OPTIONS",
  ...extra
});
async function handler(event) {
  if (event.httpMethod === "OPTIONS")
    return { statusCode: 204, headers: cors(event) };
  if (event.httpMethod !== "POST")
    return json(405, { error: "Method Not Allowed" }, cors(event));
  try {
    const { uid, priceId, sku = "pro", success_url, cancel_url } = JSON.parse(event.body || "{}");
    if (!uid || !priceId)
      return json(400, { error: "Missing uid or priceId" }, cors(event));
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      payment_method_types: ["card"],
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: success_url || `${event.headers.origin}/pro.html?status=success`,
      cancel_url: cancel_url || `${event.headers.origin}/pro.html?status=cancel`,
      metadata: { uid, sku }
    });
    return json(200, { id: session.id, url: session.url }, cors(event));
  } catch (e) {
    console.error("[create-checkout-session] error:", e);
    return json(500, { error: e.message }, cors(event));
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
